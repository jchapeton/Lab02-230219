﻿using App.Examen.Data.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using App.Examen.Data.DataAccess;
namespace App.Examen.Data.Repository
{
    public class AppUnitOfWork : IAppUnitOfWork
    {
        private readonly DbContext _context;

        public IMatriculaRepository MatriculaRepository { get; set; }
        public INotasRepository NotasRepository { get; set; }
        public AppUnitOfWork()
        {
            _context = new DBDataModel();

            this.MatriculaRepository = new MatriculaRepository(_context);
            this.NotasRepository = new NotasRepository(_context);
        }


        public int Complete()
        {
            return _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
