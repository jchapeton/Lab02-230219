﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using App.Examen.Data.Repository.Interfaces;
namespace App.Examen.Data.Repository
{
    public class NotasRepository: INotasRepository
    {
        protected readonly DbContext _context;

        public NotasRepository(DbContext context)
        {
            _context = context;
        }
    }
}
