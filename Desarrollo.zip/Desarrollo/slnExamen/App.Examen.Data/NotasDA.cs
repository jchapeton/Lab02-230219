﻿using App.Examen.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Dapper;
using System.Data;
using System.Data.SqlClient;
namespace App.Examen.Data
{
    public class NotasDA : BaseConnection
    {
        public int InsertNotasTXDist(Notas objNotas)
        {
            var result = 0;

            //Con el objeto TransactionScope se inicia la transacción
            using (var tx = new TransactionScope())
            {
                try
                {
                    var sql = "insert into Notas values(@AlumnoID,@CursoID,@Nota)";
                    //1, Crea el objeto COnnection
                    using (IDbConnection cn = new SqlConnection(getConnection()))
                    {
                        cn.Query(sql,
                            new { AlumnoID = objNotas.AlumnoId, CursoID = objNotas.CursoId, objNotas.Nota });
                    }
                    //Método COmplete se confirma la transaccion
                    tx.Complete();//Se confirma la transacción
                    result = 1;
                }
                catch (Exception ex)
                {
                    //ya no va rollback, ya que si el complete no se ejecuta significa  que entrará al catch  
                    throw new Exception(ex.Message);
                }
            }//Se libera la tabla cuando sale del USING

            return result;
        }

    }
}
