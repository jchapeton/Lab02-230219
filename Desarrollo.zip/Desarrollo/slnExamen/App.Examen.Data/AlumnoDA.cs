﻿using App.Examen.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
namespace App.Examen.Data
{
    public class AlumnoDA : BaseConnection
    {
        public int InsertAlumno(Alumno objAlumno)
        {
            int result = 0;
            string sql = "insert into dbo.Alumno values(@nombre,@apellido,@direccion,@sexo,@fechaNacimiento)";
            using (IDbConnection cn = new SqlConnection(getConnection()))
            {
                cn.Open();
                IDbCommand command = new SqlCommand(sql);
                command.Connection = cn;
                command.Parameters.Add(new SqlParameter("@nombre", objAlumno.Nombre));
                command.Parameters.Add(new SqlParameter("@apellido", objAlumno.Apellido));
                command.Parameters.Add(new SqlParameter("@direccion", objAlumno.Direccion));
                command.Parameters.Add(new SqlParameter("@sexo", objAlumno.Sexo));
                command.Parameters.Add(new SqlParameter("@fechaNacimiento", objAlumno.FechaNacimiento));
                result = Convert.ToInt32(command.ExecuteNonQuery());
            }
            return result;
        }
        public IEnumerable<Alumno> GetAlumnos()
        {
            List<Alumno> listado = new List<Alumno>();
            string sql = "select AlumnoID,Nombres,Apellidos,Direccion,Sexo,FechaNacimiento from Alumno";
            using (IDbConnection cn = new SqlConnection(getConnection()))
            {
                Alumno obj = null;
                cn.Open();
                IDbCommand cmd = new SqlCommand(sql);
                cmd.Connection = cn;
                IDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    obj = new Alumno();
                    obj.AlumnoId = reader.GetInt32(reader.GetOrdinal("AlumnoID"));
                    obj.Nombre = reader.GetString(reader.GetOrdinal("Nombres"));
                    obj.Apellido = reader.GetString(reader.GetOrdinal("Apellidos"));
                    obj.Direccion = reader.GetString(reader.GetOrdinal("Direccion"));
                    obj.Sexo = reader.GetString(reader.GetOrdinal("Sexo"));
                    obj.FechaNacimiento = reader.GetDateTime(reader.GetOrdinal("FechaNacimiento"));
                    listado.Add(obj);
                }
            }
            return listado;
        }
    }
}
