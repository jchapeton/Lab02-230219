﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Transactions;
using Dapper;
using App.Examen.Entities;

namespace App.Examen.Data
{
    public class ReporteAlumnoDA : BaseConnection
    {
        public IEnumerable<ReporteAlumno> GetReporte(int grado, int curso)
        {
            var list = new List<ReporteAlumno>();
            using (var tx = new TransactionScope())
            {
                try
                {
                    var sql = "SP_MostrarNotasXFiltro";
                    //1, Crea el objeto COnnection
                    using (IDbConnection cn = new SqlConnection(getConnection()))
                    {
                        list = cn.Query<ReporteAlumno>(sql,
                            new { grado, curso }, commandType: CommandType.StoredProcedure).ToList();
                    }
                    //Método COmplete se confirma la transaccion
                    tx.Complete();//Se confirma la transacción

                }
                catch (Exception ex)
                {
                    //ya no va rollback, ya que si el complete no se ejecuta significa  que entrará al catch  
                    throw new Exception(ex.Message);
                }
            }//Se libera la tabla cuando sale del USING

            return list;
        }
    }
}
