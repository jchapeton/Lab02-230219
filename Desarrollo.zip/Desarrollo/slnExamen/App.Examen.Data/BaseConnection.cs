﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Examen.Data
{
    public class BaseConnection
    {
        public string getConnection()
        {
            string conexion = "Server=S000-00;DataBase=dbColegio;User=sa;pwd=sql";
            return conexion;
        }
    }
}
