﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Examen.Entities
{
    public class ReporteAlumno
    {
        public string NombreCompleto { get; set; }
        public string Nivel { get; set; }
        public string Curso { get; set; }
        public int Nota { get; set; }
    }
}
