﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using App.Examen.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace App.Examen.Data.Test
{
    [TestClass]
    public class ReporteAlumnoDATest
    {
        [TestMethod]
        public void GetReporteAlumno()
        {
            var da = new ReporteAlumnoDA();
            List<ReporteAlumno> list = new List<ReporteAlumno>();
            list = da.GetReporte(2, 2).ToList();

            Assert.IsTrue(list.Count > 0);
        }
    }
}
