﻿using System;
using System.Collections.Generic;
using App.Examen.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
namespace App.Examen.Data.Test
{
    [TestClass]
    public class AlumnoDATest
    {
        [TestMethod]
        public void InsertAlumno()
        {
            AlumnoDA da = new AlumnoDA();
            Alumno obj = new Alumno()
            {
                Nombre = "Luis",
                Apellido = "Suarez",
                Sexo = "M",
                Direccion = "San Isidro",
                FechaNacimiento = Convert.ToDateTime("29/05/2000")
            };
            var result = da.InsertAlumno(obj);
            Assert.IsTrue(result > 0);
        }
        [TestMethod]
        public void GetAlumnos()
        {
            AlumnoDA da = new AlumnoDA();
            List<Alumno> listado = da.GetAlumnos().ToList();

            Assert.IsTrue(listado.Count > 0);
        }
    }
}
