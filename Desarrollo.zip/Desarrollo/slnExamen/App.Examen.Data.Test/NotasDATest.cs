﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using App.Examen.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace App.Examen.Data.Test
{
    [TestClass]
    public class NotasDATest
    {
        [TestMethod]
        public void InsertNotas()
        {
            var da = new NotasDA();
            Notas obj = new Notas()
            {
                AlumnoId = 3,
                CursoId = 2,
                Nota = 15
            };
            var result = da.InsertNotasTXDist(obj);
            Assert.IsTrue(result > 0);
        }
    }
}
